package com.gcash.gcashapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GcashApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
